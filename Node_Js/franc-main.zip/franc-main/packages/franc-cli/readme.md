# franc-cli

> CLI to detect the language of text.

View the [monorepo](https://github.com/wooorm/franc) for more packages
and usage information.

## Install

```sh
npm install franc-cli --global
```

## License

[MIT](https://github.com/wooorm/franc/blob/franc/license) © [Titus Wormer](http://wooorm.com)
